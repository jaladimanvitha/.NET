﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace LinqtoSQLSample
{
    public class CustomerContext : DataContext
    {
        public CustomerContext()
            : base("Data Source = SINDHU\\SQLEXPRESS;Initial Catalog = northwind;Integrated Security = true")
        {
        }
        public Table<Customer> Customers;
    }




    [Table(Name = "Customers")]
    public class Customer
    {
        private string _CustomerID;
        [Column(IsPrimaryKey = true, Storage = "_CustomerID")]
        public string CustomerID
        {
            get
            {
                return this._CustomerID;
            }
            set
            {
                this._CustomerID = value;
            }

        }
        [Column(Name = "CompanyName")]
        public string CompanyName { get; set; }

        [Column(Name = "ContactName")]
        public string ContactName { get; set; }

        [Column(Name = "ContactTitle")]
        public string ContactTitle { get; set; }

        [Column(Name = "Address")]
        public string Address { get; set; }

        [Column(Name = "Region")]
        public string Region { get; set; }

        [Column(Name = "PostalCode")]
        public string PostalCode { get; set; }

        [Column(Name = "Country")]
        public string Country { get; set; }

        [Column(Name = "Phone")]
        public string Phone { get; set; }

        [Column(Name = "Fax")]
        public string Fax { get; set; }

        private string _City;
        [Column(Storage = "_City")]
        public string City
        {
            get
            {
                return this._City;
            }
            set
            {
                this._City = value;
            }
        }

    }

    class Program
    {
        public static void Main(string[] args)
        {
            ReadCustomers();

       //     InsertRow();

         //   EditRow();

           // DeleteRow();

            Console.WriteLine ("Try reading diff method *********");

            ReadCustomers();

        }

        public static void ReadCustomers()
        {
            // Use a connection string.
            //DataContext db = new DataContext
            //    (@"c:\linqtest5\northwind.mdf");


            CustomerContext db = new CustomerContext();

            // Get a typed table to run queries.
            Table<Customer> Customers = db.GetTable<Customer>();

            // Attach the log to show generated SQL.
            db.Log = Console.Out;

            // Query for customers in London.
            IQueryable<Customer> custQuery =
                from cust in Customers
                where cust.City == "London"
                select cust;

            foreach (Customer cust in custQuery)
            {
                Console.WriteLine("ID={0}, City={1}", cust.CustomerID,
                    cust.City);
            }

            


        }

        public static void InsertRow()
        {

            CustomerContext custContext = new CustomerContext();
            

            Customer cust = new Customer();
            cust.CustomerID = "EDU55";
            cust.Address = "ABC";
            cust.City = "Bangalore";
            cust.CompanyName = "EDU";
            cust.ContactName = "Sam";
            cust.ContactTitle = "Trainer";
            cust.Country = "India";
            cust.Fax = "999";
            cust.Phone = "999";
            cust.PostalCode = "999";
            cust.Region = "South";


            custContext.Customers.InsertOnSubmit(cust);
            custContext.SubmitChanges();



        }


        public static void EditRow()
        {
            CustomerContext custContext = new CustomerContext();

            Customer cust = custContext.Customers.Single(c => c.CustomerID == "EDU55");
            cust.Country = "USA";

            custContext.SubmitChanges();
        }


        public static void DeleteRow()
        {
            CustomerContext custContext = new CustomerContext();

            Customer cust = custContext.Customers.Single(c => c.CustomerID == "EDU55");
            
            custContext.Customers.DeleteOnSubmit(cust);

                custContext.SubmitChanges();
        }

    }
}
