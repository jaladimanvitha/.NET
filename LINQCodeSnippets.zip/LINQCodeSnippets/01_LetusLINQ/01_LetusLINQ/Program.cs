﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace _01_LetusLINQ
{
    class IntroToLINQ
    {
        static void Main()
        {
            // The Three Parts of a LINQ Query: 
            //  1. Data source. 
            int[] numbers = new int[7] { 0, 1, 2, 3, 4, 5, 6 };

            // 2. Query creation. 
            // numQuery is an IEnumerable -- Query Syntax
            var numQuery =
                from num in numbers
                where (num % 2) == 0
                select num;

            // 3. Query execution. 
            foreach (int num in numQuery)
            {
                Console.Write("{0} ", num);
            }

            // 4. Let us see the Lambda version -- Method Syntax
            var numQueryLambda = numbers.Where(num => (num % 2 == 0));

            Console.WriteLine();

            // 5. Query Execution of the Lambda version 
            foreach (int num in numQueryLambda)
            {
               
                Console.Write("{0} ", num);
            }

            Console.ReadLine();
        }
    }

}
