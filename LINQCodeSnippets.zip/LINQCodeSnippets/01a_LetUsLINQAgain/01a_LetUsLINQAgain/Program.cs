﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01a_LetUsLINQAgain
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] somevalues = { 10, 20, 5, 2, 40, 1 };

            var numberOfExpectedValues =  (from s in somevalues 
                                          where (s > 10)
                                            select s).Count();

            var numberOfExpectedValuesLambda = somevalues.Count(x => x > 10);


            Console.WriteLine("The result of query expression " + numberOfExpectedValues);

            Console.WriteLine("The result of lamba expression " + numberOfExpectedValuesLambda);

            Console.ReadLine();

            

                                          
        }
    }
}
