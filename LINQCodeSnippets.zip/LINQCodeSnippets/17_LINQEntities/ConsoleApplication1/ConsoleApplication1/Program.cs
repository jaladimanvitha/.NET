﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace _17_LINQEntities
{
    class Person
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public string gen { get; set; }
        public int age { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> people = new List<Person>();

            people.Add(new Person() { pid = 1, pname = "Anna", gen = "Female", age = 37 });
            people.Add(new Person() { pid = 2, pname = "Beena", gen = "Female", age = 36 });
            people.Add(new Person() { pid = 3, pname = "Carry", gen = "Male", age = 30 });
            people.Add(new Person() { pid = 4, pname = "Dennis", gen = "Male", age = 40 });

            var AllPeople = from p in people select p;


            foreach (var p in AllPeople)
                Console.WriteLine(p.pid + " " + p.pname + " " + p.gen + " " + p.age);

            var MalePeople = from p in people where p.gen == "Male" select p;

            foreach (var p in MalePeople)
                Console.WriteLine(p.pid + " " + p.pname + " " + p.age);

            var FemalePeople = from p in people where p.gen == "Female" select p;

            foreach (var p in FemalePeople)
                Console.WriteLine(p.pid + " " + p.pname + " " + p.age);

            Console.ReadKey();

        }
    }
}
