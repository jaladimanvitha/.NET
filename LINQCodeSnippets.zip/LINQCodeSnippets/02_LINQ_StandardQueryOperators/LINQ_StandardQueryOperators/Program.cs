﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_StandardQueryOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            var numberGroups =
                from n in numbers
                 group n by n % 2 into g
                select new { Remainder = g.Key, Numbers = g };

            //The Lambda equivalent
            var numberGroupsLambda =
                numbers.GroupBy(n => n % 2)
                        .Select(g => new { Remainder = g.Key, Numbers = g });               

            foreach (var g in numberGroups)
            {
                Console.WriteLine("Numbers with a remainder of {0} when divided by 2:", g.Remainder);
                foreach (var n in g.Numbers)
                {
                    Console.WriteLine(n);
                }
            }

            //Iterate thru the results of the Lambda expression
            foreach (var g in numberGroupsLambda)
            {
                Console.WriteLine("Numbers with a remainder of {0} when divided by 2 using Lambda:", g.Remainder);
                foreach (var n in g.Numbers)
                {
                    Console.WriteLine(n);
                }
            }

            

            Console.ReadLine();
        }
    }
}

