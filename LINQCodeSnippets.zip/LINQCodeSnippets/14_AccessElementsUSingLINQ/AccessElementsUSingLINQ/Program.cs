﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AccessElementsUSingLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement xelement = XElement.Load("..\\..\\Employees.xml");

            IEnumerable<XElement> employees = xelement.Elements();

            Console.WriteLine("List of all Employee Names along with their ID:");

            foreach (var employee in employees)
            {

                Console.WriteLine("{0} has Employee ID {1}",

                    employee.Element("Name").Value,

                    employee.Element("EmpId").Value);

            }

            Console.ReadLine();
        }
    }
}
