﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQLetSample
{
    class Program
    {
       

    static void Main()
    {
        string[] strings = 
        {
            "A penny saved is a penny earned.",
            "The early bird catches the worm.",
            "The pen is mightier than the sword." 
        };

        // Split the sentence into an array of words 
        // and select those whose first letter is a vowel. 
        var earlyBirdQuery =
            from sentence in strings
            let words = sentence.Split(' ')
            from word in words
            let w = word.ToLower()
            where w[0] == 'a' || w[0] == 'e'
                || w[0] == 'i' || w[0] == 'o'
                || w[0] == 'u'
            select word;

        //Lambda expression equivalent
        //There is no let 
        //just use multi line lambda
        var vowels = new List<string> {"a","e","i","o","u"};

        //Lambda expression equivalent

        //var midQuery = strings.Select(sentence => sentence.ToLower().Split(' '));

        //var finalQuery = midQuery.Where(s => (s[0][0] == 'a' || s[0][0] == 'e' || s[0][0] == 'i' || s[0][0] == 'o' || s[0][0] == 'u'));
                                  

        List<string> newlist = new List<string>();
               
     
        foreach(string s in strings)
        {
            string[] wordArray = s.Split(new string[]{" "}, StringSplitOptions.None);
            foreach (var word1 in wordArray)
            {
                newlist.Add(word1);
            }

        }


        var words4 = (from p in newlist
                      where
                      (vowels.Any(v => p.ToLower().StartsWith(v)))
                      select p);


        string instr = string.Join(",", strings);

        string[] outstr = instr.Split(' ');

        var words5 = (from p in outstr
                      where
                      (vowels.Any(v => p.ToLower().StartsWith(v)))
                      select p);
        
        // Execute the query. 
        foreach (var v in earlyBirdQuery)
        {
            Console.WriteLine("\"{0}\" starts with a vowel", v);
        }


        Console.WriteLine("Now for the Lambda version");



        foreach (var v in words4)
        {
            Console.WriteLine("\"{0}\" starts with a vowel", v);
        }

        Console.WriteLine("Now for the alternate Lambda expression");

        foreach (var v in words5)
        {
            Console.WriteLine("\"{0}\" starts with a vowel", v);
        }


       


       


        // Keep the console window open in debug mode.
        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }
}

        }
    

