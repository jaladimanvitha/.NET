﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_LINQIntoClause
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a data source. 
            string[] words = { "apples", "blueberries", "oranges", "bananas", "apricots" };

            // Create the query. 
            var wordGroups1 =
                from w in words
                group w by w[0] into fruitGroup
                where fruitGroup.Count() >= 2
                select new { FirstLetter = fruitGroup.Key, Words = fruitGroup.Count() };

            //Create the same query using Lambda expression
            var wordGroups2 = words.GroupBy(w => w[0])
                                      .Where(fruitGroup => fruitGroup.Count() >= 2)
                                      .Select(fruitGroup => new { FirstLetter = fruitGroup.Key, Words = fruitGroup.Count() });

            // Execute the query. Note that we only iterate over the groups,  
            // not the items in each group 
            foreach (var item in wordGroups1)
            {
                Console.WriteLine(" {0} has {1} elements.", item.FirstLetter, item.Words);
            }

            //Execute the lambda expression
            foreach (var item in wordGroups2)
            {
                Console.WriteLine(" {0} has {1} elements.", item.FirstLetter, item.Words);
            }

            // Keep the console window open in debug mode
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
