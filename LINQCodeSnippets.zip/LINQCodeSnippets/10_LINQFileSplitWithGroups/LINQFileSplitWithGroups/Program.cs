﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQFileSplitWithGroups
{
    class SplitWithGroups
    {
        static void Main()
        {
            string[] fileA = System.IO.File.ReadAllLines(@"../../../names1.txt");
            string[] fileB = System.IO.File.ReadAllLines(@"../../../names2.txt");

            // Concatenate and remove duplicate names based on 
            // default string comparer 
            var mergeQuery = fileA.Union(fileB);

            // Group the names by the first letter in the last name. 
            var groupQuery = from name in mergeQuery
                             let n = name.Split(',')
                             group name by n[0][0] into g
                             orderby g.Key
                             select g;



            var inQuery = mergeQuery.Select(name => name.Split(','));

            
            var outstr = inQuery.GroupBy(n => n[0][0])
                                  .OrderBy(g => g.Key);

           
            // Create a new file for each group that was created 
            // Note that nested foreach loops are required to access 
            // individual items with each group. 
            foreach (var g in groupQuery)
            {
                // Create the new file name. 
                string fileName = @"../../../testFile_" + g.Key + ".txt";

                // Output to display.
                Console.WriteLine(g.Key);

                // Write file. 
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fileName))
                {
                    foreach (var item in g)
                    {
                        sw.WriteLine(item);
                        // Output to console for example purposes.
                        Console.WriteLine("   {0}", item);
                    }
                }
            }

            foreach (var g in outstr)
            {
                // Create the new file name. 
                string fileName = @"../../../testFile1_" + g.Key + ".txt";

                // Output to display.
                Console.WriteLine(g.Key);

                // Write file. 
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(fileName))
                {
                    foreach (var item in g)
                    {
                        sw.WriteLine(item);
                        // Output to console for example purposes.
                        Console.WriteLine("   {0}", item);
                    }
                }
            }
            // Keep console window open in debug mode.
            Console.WriteLine("Files have been written. Press any key to exit");
            Console.ReadKey();
        }
    }

}
