﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCFClientForStudentService.StudentServiceReference;

namespace WCFClientForStudentService
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            StudentServiceReference.StudentServiceClient client = new StudentServiceClient(BasicHttpBinding_IStudentService);

            string studentFullName = client.GetStudentFullName(1001);

        }

        public string BasicHttpBinding_IStudentService { get; set; }
    }
}
