﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace QueryElementXML
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement xelement = XElement.Load("..\\..\\Employees.xml");

            var addresses = from address in xelement.Elements("Employee")

                            where (string)address.Element("Address").Element("City") == "Alta"

                            select address;

            var addressLambda =  xelement.Elements("Employee").Where(address=>(string)address.Element("Address").Element("City") == "Alta" );
                                                                

            Console.WriteLine("Details of Employees living in Alta City");

            foreach (XElement xEle in addresses)

                Console.WriteLine(xEle);

            Console.WriteLine("Details of Employees living in Alta City using the Lambda expression");

            foreach (XElement xEle in addressLambda)

                Console.WriteLine(xEle);

            Console.ReadLine();
        }
    }
}
