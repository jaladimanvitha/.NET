﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO;
using System.Xml;

namespace SaveXMLLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            XNamespace empNM = "urn:lst-emp:emp";



            XDocument xDoc = new XDocument(

                        new XDeclaration("1.0", "UTF-16", null),

                        new XElement(empNM + "Employees",

                            new XElement("Employee",

                                new XComment("Only 3 elements for demo purposes"),

                                new XElement("EmpId", "5"),

                                new XElement("Name", "Kimmy"),

                                new XElement("Sex", "Female")

                                )));



            StringWriter sw = new StringWriter();

            XmlWriter xWrite = XmlWriter.Create(sw);

            xDoc.Save(xWrite);

            xWrite.Close();



            // Save to Disk

            xDoc.Save("e:\\Something.xml");

            Console.WriteLine("Saved");
        }
    }
}
