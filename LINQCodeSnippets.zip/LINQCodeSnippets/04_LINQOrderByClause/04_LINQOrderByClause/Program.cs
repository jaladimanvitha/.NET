﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_LINQOrderByClause
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a delicious data source. 
            string[] fruits = { "cherry", "apple", "blueberry" };

            // Query for ascending sort.
            IEnumerable<string> sortAscendingQuery =
                from fruit in fruits
                orderby fruit //"ascending" is default 
                select fruit;

            //Lambda equivalent of the ascending query
            IEnumerable<string> sortAscendingLambda = fruits.OrderBy(fruit => fruit);

            //Lambda equivalent of descending           
            IEnumerable<string> sortDescendingLambda = fruits.OrderByDescending(fruit => fruit);


            // Query for descending sort.
            IEnumerable<string> sortDescendingQuery =
                from w in fruits
                orderby w descending
                select w;

            // Execute the query.
            Console.WriteLine("Ascending:");
            foreach (string s in sortAscendingQuery)
            {
                Console.WriteLine(s);
            }

            // Execute the query.
            Console.WriteLine(Environment.NewLine + "Descending:");
            foreach (string s in sortDescendingQuery)
            {
                Console.WriteLine(s);
            }



            // Execute the query.
            Console.WriteLine("Ascending Lambda:");
            foreach (string s in sortAscendingLambda)
            {
                Console.WriteLine(s);
            }

            // Execute the query.
            Console.WriteLine(Environment.NewLine + "Descending Lambda:");
            foreach (string s in sortDescendingLambda)
            {
                Console.WriteLine(s);
            }

            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();

        }
    }
}
